/*package yangxiao.cauc.Private_Client;

import java.applet.Applet;
import java.applet.AudioClip;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.URL;

import yangxiao.cauc.chat.Message;
import yangxiao.cauc.chat.Translate;

public class ReceiveMessage extends Thread{
	private DatagramSocket clientSocket;
	private private_Client parentUI;
	private byte[] data = new byte[8096];  	//8KB����
	public ReceiveMessage(DatagramSocket socket, private_Client pri_clinet) {
		// TODO Auto-generated constructor stub
		this.clientSocket = socket;
		this.parentUI = pri_clinet;
	}
	@Override
	public void run() {
		while(true) {
			try {
				DatagramPacket packet = new DatagramPacket(data, data.length);	//�������ձ���
				clientSocket.receive(packet);		//����
				Message msg = (Message)Translate.ByteToObject(data);	//��ԭ��Ϣ����
				if(msg.getType().equals("M_PRIVATE")) {
					if(msg.getText()==null) {
						String tempId = msg.getUserId();
						msg.setUserId(msg.getTargetId());
						msg.setTargetId(tempId);
						private_Client pri_client = new private_Client(clientSocket, msg);
						pri_client.setVisible(true);
						pri_client.setTitle(msg.getUserId() + " to " + msg.getTargetId());
					}
					else {
					playSound("/yangxiao/cauc/sounds/msg.wav");	//��Ϣ��ʾ��
					parentUI.msgWindow.append(msg.getUserId() + " : " + msg.getText() + "\n");
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}
	private void playSound(String filename) {
		URL url = AudioClip.class.getResource(filename);
		AudioClip sound;
		sound = Applet.newAudioClip(url);
		sound.play();
	}
}*/