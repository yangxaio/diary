package yangxiao.cauc.Private_Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import yangxiao.cauc.Client.ReceiveMessage;
import yangxiao.cauc.chat.Message;
import yangxiao.cauc.chat.Translate;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.awt.event.ActionEvent;

public class private_Client extends JFrame {

	private JPanel contentPane;
	protected JTextArea talkWindow;
	public JTextArea msgWindow;
	private DatagramSocket clientSocket;
	private Message msg;
	private byte[] data = new byte[8096];	//����һ��8KB��С������

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					private_Client frame = new private_Client();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public private_Client() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 554, 442);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane topscrollPane = new JScrollPane();
		topscrollPane.setViewportBorder(new TitledBorder(null, "\u4F1A\u8BDD\u6D88\u606F\u7A97\u53E3", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		topscrollPane.setBounds(0, 35, 536, 155);
		contentPane.add(topscrollPane);
		
		msgWindow = new JTextArea();
		topscrollPane.setViewportView(msgWindow);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new TitledBorder(null, "\u53D1\u8A00\u7A97\u53E3", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		scrollPane.setBounds(0, 204, 536, 134);
		contentPane.add(scrollPane);
		
		talkWindow = new JTextArea();
		scrollPane.setViewportView(talkWindow);
		
		JButton btnSend = new JButton("\u53D1\u9001");
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSendActionPerformed();
			}
		});
		btnSend.setBounds(402, 355, 120, 27);
		contentPane.add(btnSend);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	private void btnSendActionPerformed() {
		try {
			if(talkWindow.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "�������ı�", "������ʾ", JOptionPane.ERROR_MESSAGE);
			}else {
				msg.setType("M_PRIVATE");
				msg.setText(talkWindow.getText());		//��ȡ˽��������ı�
				msgWindow.append(msg.getUserId() + ": " + msg.getText() + "\n");
				data = Translate.ObjectToByte(msg);
				DatagramPacket packet = new DatagramPacket(data, data.length, msg.getToAddr(), msg.getToport());
				clientSocket.send(packet);
				talkWindow.setText("");
			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "������ʾ", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public private_Client(DatagramSocket socket, Message msg) throws IOException {
		this();
		this.clientSocket = socket;
		this.msg = msg;
		this.setTitle(msg.getUserId() + " to " + msg.getTargetId());
		//�����ͻ���˽����Ϣ���պʹ����߳�
		/*Thread privateThread = new ReceiveMessage(clientSocket, this);
		privateThread.start();*/
	}
}