package yangxiao.cauc.chat.Server;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class DbOperation {
	private Connection con;
	private Statement stmt;
	public DbOperation(DataBaseConnection database) {
		this.con = database.getconnection();	//ȡ�����Ӷ���
		this.stmt = database.getStatement();	//ȡ��SQL���
	}
	public boolean login(String ID,String password) throws SQLException {
		boolean result = false;
		String sql = "select * from [User]";
		try {
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {	//ָ�벻�Ϻ���
				if(rs.getString(1).equals(ID) && rs.getString(2).equals(password)) {
					result = true;
					break;
				}
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public void register(String id, String password){
		try {
			boolean isregister = false;
			String sql2 = "select * from [User]";
			ResultSet rs = stmt.executeQuery(sql2);
			while(rs.next()) {
				if(rs.getString(1).equals(id)) {
					isregister = true;
					break;
				}
			}
			if(!isregister) {
				String sql = "insert into [User](ID,Password)values('"+ id +"' , '" +password +"')";
				stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(null, "ע��ɹ�", "��ʾ", JOptionPane.DEFAULT_OPTION);
			}else {
				JOptionPane.showMessageDialog(null, "���û��Ѵ���", "ע��ʧ��", JOptionPane.ERROR_MESSAGE);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
