package yangxiao.cauc.chat.Server;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Server extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtHostName;
	private JTextField txtHostPort;
	protected JTextArea txtArea;
	private JButton btnStart;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Server frame = new Server();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Server() {
		setTitle("\u670D\u52A1\u5668");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 732, 416);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new TitledBorder(null, "\u542F\u52A8\u670D\u52A1\u5668", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		topPanel.setBounds(5, 5, 704, 86);
		contentPane.add(topPanel);
		topPanel.setLayout(null);
		
		JLabel Jlabel = new JLabel("\u4E3B\u673A\u540D\uFF1A");
		Jlabel.setBounds(46, 35, 72, 18);
		topPanel.add(Jlabel);
		
		txtHostName = new JTextField();
		txtHostName.setBounds(111, 32, 130, 24);
		topPanel.add(txtHostName);
		txtHostName.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u7AEF\u53E3\uFF1A");
		lblNewLabel_1.setBounds(325, 35, 45, 18);
		topPanel.add(lblNewLabel_1);
		
		txtHostPort = new JTextField();
		txtHostPort.setBounds(384, 32, 120, 24);
		topPanel.add(txtHostPort);
		txtHostPort.setColumns(10);
		
		btnStart = new JButton("\u542F\u52A8");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnStartActionPerformed(null);
			}
		});
		btnStart.setBounds(577, 31, 113, 27);
		topPanel.add(btnStart);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new TitledBorder(null, "\u804A\u5929\u5BA4\u5927\u5385", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		scrollPane.setBounds(5, 104, 695, 252);
		contentPane.add(scrollPane);
		
		txtArea = new JTextArea();
		scrollPane.setViewportView(txtArea);
	}
	
	private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			//��ȡ������������ַ�˿�
			String hostname = txtHostName.getText();
			InetAddress remoteAdd = InetAddress.getByName(hostname);
			/*��Ϊ���ڱ������ܵĳ���������ʱ���ǲ���Ҫ����IP��ַ��*/
			int hostPort = Integer.parseInt(txtHostPort.getText());
			/*����UDP���ݱ��׽��֣�����ָ���˿�*/
			DatagramSocket serverSocket = new DatagramSocket(hostPort);
			txtArea.append("��������ʼ����...\n");
			//����UDP��Ϣ�����߳�
			Thread recvThread = new ReceiveMessage(serverSocket, this);
			recvThread.start(); 		//�����߳�
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "������ʾ", JOptionPane.ERROR_MESSAGE);
		}
		btnStart.setEnabled(false);
	}
}